let notificationInterval;

const cardsContainer = document.getElementById('cards-container');

// Example cards
const cards = [
  { title: "Live Better", text: "Available Balance", image: "img_liveBetter_logo.svg", id: "" },
  { title: "Capitec Connect", text: "Connecting you for less", image: "img_capitecConnect_logo.png", id: "" },
  { title: "Always There For you", text: "Near by deals", image: "img_prox_logo.png", id: "proximityMenuButton" },
  { title: "Easy Equities", text: "Investing made easy", image: "img_easyEquities_logo.png", id: "" }
];

// Render cards dynamically
cards.forEach(card => {
  const cardDiv = document.createElement('div');
  cardDiv.id = card.id;
  cardDiv.className = 'card';
  cardDiv.innerHTML = `
    <img src="${card.image}" alt="${card.title}">
    <div>
      <h3>${card.title}</h3>
      <p>${card.text}</p>
    </div>
  `;
  cardsContainer.appendChild(cardDiv);
});

// Toggle functionality
const toggle = document.getElementById('opt-in-toggle');
const toggleStatus = document.getElementById('toggle-status');

toggle.addEventListener('change', () => {

  localStorage.setItem('optInToggle', toggle.checked); // Save state

  toggleStatus.textContent = toggle.checked ? 'You have Opted-In' : 'You have not Opted-In';
  toggle.checked ? cardsContainerBiz.classList.remove('hidden') : cardsContainerBiz.classList.add('hidden');
  toggle.checked ? titleBiz.classList.remove('hidden') : titleBiz.classList.add('hidden');

  toggle.checked ? spacer1.classList.add('hidden') : spacer1.classList.remove('hidden');
});

// Slider functionality
const slider = document.getElementById('frequency-slider');
const sliderValue = document.getElementById('slider-value');

// Load the saved frequency from localStorage
const storedFrequency = localStorage.getItem('frequencyValue') || 30; // Default to 30 mins
slider.value = storedFrequency; // Set the slider to the saved value
updateSliderDisplay(storedFrequency); // Update the display text

// Update frequency when the slider value changes
slider.addEventListener('input', () => {
  const newFrequency = slider.value;
  localStorage.setItem('frequencyValue', newFrequency); // Save the value to localStorage
  updateSliderDisplay(newFrequency); // Update the display text
});

// Function to update the slider display
function updateSliderDisplay(frequency) {
  const time = frequency < 60 ? `${frequency} mins` : `${Math.floor(frequency / 60)} hours`;
  sliderValue.textContent = time;
}

document.addEventListener('DOMContentLoaded', () => {

  const savedToggle = localStorage.getItem('optInToggle');

  if (savedToggle !== null) {

    toggle.checked = savedToggle === 'true';
    toggleStatus.textContent = toggle.checked ? 'You have Opted-In' : 'You have not Opted-In';
    toggle.checked ? cardsContainerBiz.classList.remove('hidden') : cardsContainerBiz.classList.add('hidden');
    toggle.checked ? titleBiz.classList.remove('hidden') : titleBiz.classList.add('hidden');

    toggle.checked ? spacer1.classList.add('hidden') : spacer1.classList.remove('hidden');
  }
});

const cardsContainerBiz = document.getElementById('cards-container-biz');
const cardsBiz = [
  { title: "The Coffee Bar", text: "1 free coffee", image: "img_businessShop.png", id:"coffee" },
  { title: "Abuzz Wine", text: "Buy 6 get 10% off", image: "https://via.placeholder.com/50", id:"" },
  { title: "Aleph Biltong", text: "Buy 2 get 1 free", image: "https://via.placeholder.com/50", id:"" },
  { title: "Bellezza Skincare Clinic", text: "20% discount", image: "https://via.placeholder.com/50", id:"" },
  { title: "Base Fit", text: "First-time visit free", image: "https://via.placeholder.com/50", id:"" },
  { title: "Cornerstone Cafe", text: "15% off first order", image: "https://via.placeholder.com/50", id:"" },
  { title: "Eikestad Dental", text: "R500 off first teeth whitening", image: "https://via.placeholder.com/50", id:"" },
  { title: "Lizal's Food Truck ", text: "10% off lunch specials", image: "https://via.placeholder.com/50", id:"" },
  { title: "Lizzy at Technohair", text: "20% off highlights", image: "https://via.placeholder.com/50", id:"" },
  { title: "Mugg and Bean", text: "R50 off order", image: "https://via.placeholder.com/50", id:"" }
];

// Function to render a card
function renderCard(card) {
  const cardDiv = document.createElement('div');
  cardDiv.className = 'card';
  cardDiv.id = card.id;
  cardDiv.innerHTML = `
    <img src="img_businessShop.png" alt="${card.title}">
    <div>
      <h3>${card.title}</h3>
      <p>${card.text}</p>
    </div>
  `;
  cardsContainerBiz.appendChild(cardDiv);
}

renderCard(cardsBiz[0]);

const remainingCards = cardsBiz.slice(1);
const randomCards = [];
while (randomCards.length < 4) {
  const randomIndex = Math.floor(Math.random() * remainingCards.length);
  const selectedCard = remainingCards.splice(randomIndex, 1)[0]; // Remove and select a random card
  randomCards.push(selectedCard);
}

randomCards.forEach(card => renderCard(card));

const homePage = document.getElementById('homePage');
const proximityPage = document.getElementById('proximityPage');
const voucherPage = document.getElementById('voucherPage');

const proximityMenuButton = document.getElementById('proximityMenuButton');
const homeButton = document.getElementById('homeButton');

const coffeeCard = document.getElementById('coffee');

const spacer1 = document.getElementById('spacer1');
const titleBiz = document.getElementById('titleBiz');

const hideAllPages = () => {

  homePage.classList.add('hidden');
  proximityPage.classList.add('hidden');
  voucherPage.classList.add('hidden');
}

proximityMenuButton.addEventListener('click', async () => {

  hideAllPages();
  proximityPage.classList.remove('hidden');
});

homeButton.addEventListener('click', async () => {

  hideAllPages();
  homePage.classList.remove('hidden');
});

coffeeCard.addEventListener('click', async () => {

  hideAllPages();
  voucherPage.classList.remove('hidden');
});
